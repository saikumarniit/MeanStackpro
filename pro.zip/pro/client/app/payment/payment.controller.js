'use strict';

(function(){

class PaymentComponent {


constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.awesomeThings = [];
    //this.amount = [];

    $scope.$on('$destroy', function() {
      socket.unsyncUpdates('thing');
    });
  }

  $onInit() {
    this.$http.get('/api/payment')
      .then(response => {
        this.awesomeThings = response.data;
      //  this.amount=(this.nticket*120)+30;
        this.socket.syncUpdates('Bookings', this.awesomeThings);
      });
  }

  addThing() {
        this.tamount=this.nticket*120+30;
        this.$http.post('/api/payment', {
        noofticket: this.nticket,
        amount: this.tamount
      });
    //  window.alert(this.tamount);
      this.socket.syncUpdates('Bookings', this.awesomeThings);
      //this.nticket = '0';

}
thanks()
{
     window.alert('Ticket are Booked..! Thanks for Booking..');
}

}
angular.module('myResearchApp')
  .component('payment', {
    templateUrl: 'app/payment/payment.html',
    controller: PaymentComponent

  });

})();
