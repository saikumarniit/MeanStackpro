
'use strict';
(function(){

class SeatbookingComponent {
  constructor($http, $scope, socket) {
    this.message = 'Hello';
    this.$http = $http;
    this.socket = socket;
    this.myMovies = [];

    $scope.$on('$destroy', function() {
      socket.unsyncUpdates('seatbooking');
    });
  }
  $onInit() {
    this.$http.get('api/seatbooking')
      .then(response => {
        this.myMovies = response.data;
        this.socket.syncUpdates('seatbooking', this.myMovies);
        console.log(response.data);
      });
  }
}
angular.module('myResearchApp')
  .component('seatbooking', {
    templateUrl: 'app/seatbooking/seatbooking.html',
    controller: SeatbookingComponent
    //controllerAs: Seatbooking
  });

})();
