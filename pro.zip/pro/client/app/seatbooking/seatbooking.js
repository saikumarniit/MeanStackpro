'use strict';

angular.module('myResearchApp')
  .config(function ($routeProvider) {
    $routeProvider
      .when('/seatbooking', {
        template: '<seatbooking></seatbooking>'
      }).
      when('/payment/:Title/:theater/:timing',
      {
      templateUrl:'app/payment/payment.html',
      controller:'paymentController',
      controllerAs:'pb'
    });
  angular.module('myResearchApp').controller('paymentController',['$route',function($route)
  {
    this.params=$route.current.params;
  }]);
  });
