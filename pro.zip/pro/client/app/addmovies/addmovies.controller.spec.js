'use strict';

describe('Component: AddmoviesComponent', function () {

  // load the controller's module
  beforeEach(module('myResearchApp'));

  var AddmoviesComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    AddmoviesComponent = $componentController('addmovies', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
