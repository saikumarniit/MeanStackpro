'use strict';

(function(){

class AddmoviesComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.awesomeThings = [];
    $scope.$on('$destroy', function() {
      socket.unsyncUpdates('thing');
    });
  }
  $onInit() {
    this.$http.get('/api/addmovies')
      .then(response => {
        this.awesomeThings = response.data;
        console.log('data:'+this.awesomeThings);
      console.log(' i am in controller');
      window.alert('on init() called');
        this.socket.syncUpdates('thing', this.awesomeThings);
      });
  }
  //$onInit()
  //{
/*    this.$http.get('http://www.omdbapi.com/?t=frozen&y=&plot=short&r=json')
      .then(response => {
        this.awesomeThings = response.data;
      //  window.alert(JSON.stringify(this.awesomeThings));
      this.awesomeThings=JSON.stringify(this.awesomeThings);

              this.socket.syncUpdates('thing', this.awesomeThings);
      });*/
  //}
/*getData()
{
  if(this.Title&&this.Year)
  {
  this.$http.get('http://www.omdbapi.com/?t='+this.Title+'&y='+this.Year+'&r=json')
  .then(response => {
    this.details = response.data;
      window.alert(JSON.stringify(this.details));
  this.details=JSON.stringify(this.details);
      //  window.alert(this.awesomeThings);
          this.socket.syncUpdates('thing', this.details);
  });
}
}*/


getData() {
    this.$http.get('https://www.omdbapi.com/?t=' + this.t + '&y='+this.y + '&plot=short&r=json')
      //.sucess(addMovie(data));
      .then(response => {
        this.movieData = response.data;
        this.socket.syncUpdates('movie', this.movieData);
      });
  }


  addMovie() {
      if (this.movieData) {
        window.alert('movie data:'+JSON.stringify(this.movieData));
        this.$http.post('/api/addmovies',
          JSON.stringify(this.movieData)
        );
             window.alert('movie added successfully');
      }
    }
  deleteMovie(thing) {
    this.$http.delete('/api/addmovies/' + thing._id);
  }
}

angular.module('myResearchApp')
  .component('addmovies', {
    templateUrl: 'app/addmovies/pm.html',
    controller: AddmoviesComponent
  });

})();
