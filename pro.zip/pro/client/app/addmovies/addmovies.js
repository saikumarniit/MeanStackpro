'use strict';

angular.module('myResearchApp')
  .config(function ($routeProvider) {
    $routeProvider
      .when('/addmovies', {
        template: '<addmovies></addmovies>'
      });
  });
