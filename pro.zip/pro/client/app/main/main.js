'use strict';

angular.module('myResearchApp')
  .config(function($routeProvider) {
    $routeProvider.when('/', {
      template: '<main></main>'
    }).
    when('/seatbooking/:Title/:theater/:timing',
    {
    templateUrl:'app/seatbooking/seatbooking.html',
    controller:'seatBookingController',
    controllerAs:'sb'
  });
});
angular.module('myResearchApp').controller('seatBookingController',['$route',function($route)
{
  this.params=$route.current.params;
}]);
