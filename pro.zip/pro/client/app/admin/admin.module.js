'use strict';

angular.module('myResearchApp.admin', ['myResearchApp.auth', 'ngRoute']);
