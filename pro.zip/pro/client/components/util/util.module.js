'use strict';

angular.module('myResearchApp.util', []);
