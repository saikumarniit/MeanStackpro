'use strict';

angular.module('myResearchApp.auth', ['myResearchApp.constants', 'myResearchApp.util', 'ngCookies',
    'ngRoute'
  ])
  .config(function($httpProvider) {
    $httpProvider.interceptors.push('authInterceptor');
  });
