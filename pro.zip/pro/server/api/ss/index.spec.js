'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var ssCtrlStub = {
  index: 'ssCtrl.index',
  show: 'ssCtrl.show',
  create: 'ssCtrl.create',
  update: 'ssCtrl.update',
  destroy: 'ssCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var ssIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './ss.controller': ssCtrlStub
});

describe('Ss API Router:', function() {

  it('should return an express router instance', function() {
    expect(ssIndex).to.equal(routerStub);
  });

  describe('GET /api/sss', function() {

    it('should route to ss.controller.index', function() {
      expect(routerStub.get
        .withArgs('/', 'ssCtrl.index')
        ).to.have.been.calledOnce;
    });

  });

  describe('GET /api/sss/:id', function() {

    it('should route to ss.controller.show', function() {
      expect(routerStub.get
        .withArgs('/:id', 'ssCtrl.show')
        ).to.have.been.calledOnce;
    });

  });

  describe('POST /api/sss', function() {

    it('should route to ss.controller.create', function() {
      expect(routerStub.post
        .withArgs('/', 'ssCtrl.create')
        ).to.have.been.calledOnce;
    });

  });

  describe('PUT /api/sss/:id', function() {

    it('should route to ss.controller.update', function() {
      expect(routerStub.put
        .withArgs('/:id', 'ssCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('PATCH /api/sss/:id', function() {

    it('should route to ss.controller.update', function() {
      expect(routerStub.patch
        .withArgs('/:id', 'ssCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('DELETE /api/sss/:id', function() {

    it('should route to ss.controller.destroy', function() {
      expect(routerStub.delete
        .withArgs('/:id', 'ssCtrl.destroy')
        ).to.have.been.calledOnce;
    });

  });

});
