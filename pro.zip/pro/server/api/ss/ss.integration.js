'use strict';

var app = require('../..');
import request from 'supertest';

var newSs;

describe('Ss API:', function() {

  describe('GET /api/sss', function() {
    var sss;

    beforeEach(function(done) {
      request(app)
        .get('/api/sss')
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          sss = res.body;
          done();
        });
    });

    it('should respond with JSON array', function() {
      expect(sss).to.be.instanceOf(Array);
    });

  });

  describe('POST /api/sss', function() {
    beforeEach(function(done) {
      request(app)
        .post('/api/sss')
        .send({
          name: 'New Ss',
          info: 'This is the brand new ss!!!'
        })
        .expect(201)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          newSs = res.body;
          done();
        });
    });

    it('should respond with the newly created ss', function() {
      expect(newSs.name).to.equal('New Ss');
      expect(newSs.info).to.equal('This is the brand new ss!!!');
    });

  });

  describe('GET /api/sss/:id', function() {
    var ss;

    beforeEach(function(done) {
      request(app)
        .get('/api/sss/' + newSs._id)
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          ss = res.body;
          done();
        });
    });

    afterEach(function() {
      ss = {};
    });

    it('should respond with the requested ss', function() {
      expect(ss.name).to.equal('New Ss');
      expect(ss.info).to.equal('This is the brand new ss!!!');
    });

  });

  describe('PUT /api/sss/:id', function() {
    var updatedSs;

    beforeEach(function(done) {
      request(app)
        .put('/api/sss/' + newSs._id)
        .send({
          name: 'Updated Ss',
          info: 'This is the updated ss!!!'
        })
        .expect(200)
        .expect('Content-Type', /json/)
        .end(function(err, res) {
          if (err) {
            return done(err);
          }
          updatedSs = res.body;
          done();
        });
    });

    afterEach(function() {
      updatedSs = {};
    });

    it('should respond with the updated ss', function() {
      expect(updatedSs.name).to.equal('Updated Ss');
      expect(updatedSs.info).to.equal('This is the updated ss!!!');
    });

  });

  describe('DELETE /api/sss/:id', function() {

    it('should respond with 204 on successful removal', function(done) {
      request(app)
        .delete('/api/sss/' + newSs._id)
        .expect(204)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

    it('should respond with 404 when ss does not exist', function(done) {
      request(app)
        .delete('/api/sss/' + newSs._id)
        .expect(404)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

  });

});
