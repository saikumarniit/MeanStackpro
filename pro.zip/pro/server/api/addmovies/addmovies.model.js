'use strict';

import mongoose from 'mongoose';

var AddmoviesSchema = new mongoose.Schema({
Title :String,
 Year :String,
  Rated :String,
   Released :String,
    Runtime :String,
    Genre :String,
    Writer :String,
     Actors :String,
      Plot :String,
       Language :String,
       Country :String,
        Awards :String,
        Poster :String,
        Metascore :String,
        imdbRating :String,
         imdbVotes :String,
         imdbID :String,
          Type :String,
           Response :String,
           TheatreName:String,
           showTime:String,
  active: Boolean
});
export default mongoose.model('Addmovies', AddmoviesSchema);
