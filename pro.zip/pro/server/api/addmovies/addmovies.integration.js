'use strict';

var app = require('../..');
import request from 'supertest';

var newAddmovies;

describe('Addmovies API:', function() {

  describe('GET /api/addmovies', function() {
    var addmoviess;

    beforeEach(function(done) {
      request(app)
        .get('/api/addmovies')
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          addmoviess = res.body;
          done();
        });
    });

    it('should respond with JSON array', function() {
      expect(addmoviess).to.be.instanceOf(Array);
    });

  });

  describe('POST /api/addmovies', function() {
    beforeEach(function(done) {
      request(app)
        .post('/api/addmovies')
        .send({
          name: 'New Addmovies',
          info: 'This is the brand new addmovies!!!'
        })
        .expect(201)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          newAddmovies = res.body;
          done();
        });
    });

    it('should respond with the newly created addmovies', function() {
      expect(newAddmovies.name).to.equal('New Addmovies');
      expect(newAddmovies.info).to.equal('This is the brand new addmovies!!!');
    });

  });

  describe('GET /api/addmovies/:id', function() {
    var addmovies;

    beforeEach(function(done) {
      request(app)
        .get('/api/addmovies/' + newAddmovies._id)
        .expect(200)
        .expect('Content-Type', /json/)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          addmovies = res.body;
          done();
        });
    });

    afterEach(function() {
      addmovies = {};
    });

    it('should respond with the requested addmovies', function() {
      expect(addmovies.name).to.equal('New Addmovies');
      expect(addmovies.info).to.equal('This is the brand new addmovies!!!');
    });

  });

  describe('PUT /api/addmovies/:id', function() {
    var updatedAddmovies;

    beforeEach(function(done) {
      request(app)
        .put('/api/addmovies/' + newAddmovies._id)
        .send({
          name: 'Updated Addmovies',
          info: 'This is the updated addmovies!!!'
        })
        .expect(200)
        .expect('Content-Type', /json/)
        .end(function(err, res) {
          if (err) {
            return done(err);
          }
          updatedAddmovies = res.body;
          done();
        });
    });

    afterEach(function() {
      updatedAddmovies = {};
    });

    it('should respond with the updated addmovies', function() {
      expect(updatedAddmovies.name).to.equal('Updated Addmovies');
      expect(updatedAddmovies.info).to.equal('This is the updated addmovies!!!');
    });

  });

  describe('DELETE /api/addmovies/:id', function() {

    it('should respond with 204 on successful removal', function(done) {
      request(app)
        .delete('/api/addmovies/' + newAddmovies._id)
        .expect(204)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

    it('should respond with 404 when addmovies does not exist', function(done) {
      request(app)
        .delete('/api/addmovies/' + newAddmovies._id)
        .expect(404)
        .end((err, res) => {
          if (err) {
            return done(err);
          }
          done();
        });
    });

  });

});
