'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var addmoviesCtrlStub = {
  index: 'addmoviesCtrl.index',
  show: 'addmoviesCtrl.show',
  create: 'addmoviesCtrl.create',
  update: 'addmoviesCtrl.update',
  destroy: 'addmoviesCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var addmoviesIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './addmovies.controller': addmoviesCtrlStub
});

describe('Addmovies API Router:', function() {

  it('should return an express router instance', function() {
    expect(addmoviesIndex).to.equal(routerStub);
  });

  describe('GET /api/addmovies', function() {

    it('should route to addmovies.controller.index', function() {
      expect(routerStub.get
        .withArgs('/', 'addmoviesCtrl.index')
        ).to.have.been.calledOnce;
    });

  });

  describe('GET /api/addmovies/:id', function() {

    it('should route to addmovies.controller.show', function() {
      expect(routerStub.get
        .withArgs('/:id', 'addmoviesCtrl.show')
        ).to.have.been.calledOnce;
    });

  });

  describe('POST /api/addmovies', function() {

    it('should route to addmovies.controller.create', function() {
      expect(routerStub.post
        .withArgs('/', 'addmoviesCtrl.create')
        ).to.have.been.calledOnce;
    });

  });

  describe('PUT /api/addmovies/:id', function() {

    it('should route to addmovies.controller.update', function() {
      expect(routerStub.put
        .withArgs('/:id', 'addmoviesCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('PATCH /api/addmovies/:id', function() {

    it('should route to addmovies.controller.update', function() {
      expect(routerStub.patch
        .withArgs('/:id', 'addmoviesCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('DELETE /api/addmovies/:id', function() {

    it('should route to addmovies.controller.destroy', function() {
      expect(routerStub.delete
        .withArgs('/:id', 'addmoviesCtrl.destroy')
        ).to.have.been.calledOnce;
    });

  });

});
