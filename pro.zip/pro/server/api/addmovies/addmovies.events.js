/**
 * Addmovies model events
 */

'use strict';

import {EventEmitter} from 'events';
import Addmovies from './addmovies.model';
var AddmoviesEvents = new EventEmitter();

// Set max event listeners (0 == unlimited)
AddmoviesEvents.setMaxListeners(0);

// Model events
var events = {
  'save': 'save',
  'remove': 'remove'
};

// Register the event emitter to the model events
for (var e in events) {
  var event = events[e];
  Addmovies.schema.post(e, emitEvent(event));
}

function emitEvent(event) {
  return function(doc) {
    AddmoviesEvents.emit(event + ':' + doc._id, doc);
    AddmoviesEvents.emit(event, doc);
  }
}

export default AddmoviesEvents;
